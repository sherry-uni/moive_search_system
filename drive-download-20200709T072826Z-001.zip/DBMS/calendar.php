<html>
       <!DOCTYPE html PUBLIC “-//W3C//DTD XHTML 1.0 Transitional//EN” “http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd”>

        <html xmlns=”http://www.w3.org/1999/xhtml”>
    <head>
        <title>NCKU 影城電影查詢</title>
    </head>
<body>
    <meta http-equiv = "Content-Type" content = "text/html; charset=utf-8">
            <div id="Content" class="container">
                <div id="PageHeader" class="row">
                    <div class="col-sm-12 col-xs-12">
                       
<iframe src="https://calendar.google.com/calendar/embed?height=600&amp;wkst=1&amp;bgcolor=%23ffffff&amp;ctz=Asia%2FTaipei&amp;src=ZXFzbjA1dGFjMmN0dmhmMnRzaTRua3Fva29AZ3JvdXAuY2FsZW5kYXIuZ29vZ2xlLmNvbQ&amp;color=%23E67C73" style="border:solid 1px #777" width="1200" height="800" frameborder="0" scrolling="no"></iframe>>"

<?php
echo("<button onclick=\"
location.href='homepage.php'\"
>Back to Home</button>");
?>